1. Edit config.ini, for the devId, you can use ListDev.exe to see the id to the ASIO device;
2. Copy all files in osu\ directory to the same directory of osu!.exe (back up the original bass.dll if need);
3. Run osu!.exe;
4. Run Inject.exe (before you play any map).

Note if your system already has the vc++2010 runtime libary, you can delete all "msvcr100.dll" files here.